infos:

- psd cs3
- pngs in both sizes
- flexible and clean photoshop psd



Content:

...\cards.jpg, readme.txt

...\psd\cards.50x70.psd, cards.100x140.psd

...\png\52x72
...\png\102x142