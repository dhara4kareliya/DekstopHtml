
// $(document).ready(function() {
//     setLanguage(lang);
// });

$(".translate").click(function() {
    var selectedLang = $(this).attr("id");
    fetch(`../Language/${selectedLang}.json`)
    .then(function(response) {
        return response.json();
    })
    .then(function(jsonData) {
        console.log(jsonData);
        $(".lang").each(function(index, element) {
            var key = $(this).attr("key");
            $(this).text(jsonData[key]);
        });
    })
    .catch(function(error) {
        console.log('Error fetching JSON: ' + error);
    });
});